from app.engine import SensorReading, calculate_livability_score, evaluate_twin, structural_health_forecast


def test_healthy_reading_scores_high():
    reading = SensorReading(26, 60, 8, 20.9, 1, 0)
    assert calculate_livability_score(reading) >= 90
    assert structural_health_forecast(reading) >= 90
    assert evaluate_twin(reading).risk_level == "LOW"


def test_dangerous_reading_creates_alerts():
    reading = SensorReading(39, 95, 120, 18.5, 30, 80)
    snapshot = evaluate_twin(reading)
    assert snapshot.risk_level in {"HIGH", "CRITICAL"}
    assert len(snapshot.alerts) >= 4
