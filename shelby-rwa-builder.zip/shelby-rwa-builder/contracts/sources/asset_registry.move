module shelby_rwa::asset_registry {
    use std::signer;
    use std::vector;
    use aptos_framework::event;
    use aptos_framework::timestamp;

    const E_NOT_AUTHORIZED: u64 = 1;
    const E_ASSET_EXISTS: u64 = 2;

    struct Asset has key {
        owner: address,
        oracle: address,
        asset_id: vector<u8>,
        livability_score: u64,
        structural_score: u64,
        risk_level: u8,
        updated_at: u64,
    }

    #[event]
    struct ScoreUpdated has drop, store {
        owner: address,
        livability_score: u64,
        structural_score: u64,
        risk_level: u8,
        updated_at: u64,
    }

    public entry fun register_asset(owner: &signer, oracle: address, asset_id: vector<u8>) {
        let owner_address = signer::address_of(owner);
        assert!(!exists<Asset>(owner_address), E_ASSET_EXISTS);
        move_to(owner, Asset {
            owner: owner_address,
            oracle,
            asset_id,
            livability_score: 100,
            structural_score: 100,
            risk_level: 0,
            updated_at: timestamp::now_seconds(),
        });
    }

    public entry fun update_score(
        oracle_signer: &signer,
        owner: address,
        livability_score: u64,
        structural_score: u64,
        risk_level: u8,
    ) acquires Asset {
        let asset = borrow_global_mut<Asset>(owner);
        assert!(signer::address_of(oracle_signer) == asset.oracle, E_NOT_AUTHORIZED);
        asset.livability_score = livability_score;
        asset.structural_score = structural_score;
        asset.risk_level = risk_level;
        asset.updated_at = timestamp::now_seconds();
        event::emit(ScoreUpdated {
            owner,
            livability_score,
            structural_score,
            risk_level,
            updated_at: asset.updated_at,
        });
    }

    #[view]
    public fun get_scores(owner: address): (u64, u64, u8, u64) acquires Asset {
        let asset = borrow_global<Asset>(owner);
        (asset.livability_score, asset.structural_score, asset.risk_level, asset.updated_at)
    }
}
