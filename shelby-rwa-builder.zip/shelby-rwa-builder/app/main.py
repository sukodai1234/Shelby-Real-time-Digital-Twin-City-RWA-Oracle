from __future__ import annotations

import asyncio
import random
from dataclasses import asdict
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .engine import SensorReading, evaluate_twin

app = FastAPI(title="Shelby RWA Oracle", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = Path(__file__).resolve().parent.parent / "static"


class SensorReadingRequest(BaseModel):
    temperature_c: float = Field(ge=-20, le=70)
    humidity_pct: float = Field(ge=0, le=100)
    pm25_ug_m3: float = Field(ge=0, le=1000)
    oxygen_pct: float = Field(ge=0, le=25)
    salinity_ppt: float = Field(ge=0, le=100)
    water_level_cm: float = Field(default=0, ge=0, le=1000)

    def to_domain(self) -> SensorReading:
        return SensorReading(**self.model_dump())


def demo_reading() -> SensorReading:
    return SensorReading(
        temperature_c=round(random.uniform(25, 36), 1),
        humidity_pct=round(random.uniform(55, 92), 1),
        pm25_ug_m3=round(random.uniform(8, 70), 1),
        oxygen_pct=round(random.uniform(19.0, 21.0), 2),
        salinity_ppt=round(random.uniform(2, 24), 1),
        water_level_cm=round(random.uniform(0, 55), 1),
    )


@app.get("/")
def dashboard() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "service": "shelby-rwa-oracle"}


@app.post("/api/v1/evaluate")
def evaluate(payload: SensorReadingRequest) -> dict:
    reading = payload.to_domain()
    return {"reading": payload.model_dump(), "snapshot": evaluate_twin(reading).to_dict()}


@app.get("/api/v1/demo")
def demo() -> dict:
    reading = demo_reading()
    return {"reading": asdict(reading), "snapshot": evaluate_twin(reading).to_dict()}


@app.websocket("/ws/twin")
async def twin_stream(websocket: WebSocket) -> None:
    await websocket.accept()
    try:
        while True:
            reading = demo_reading()
            await websocket.send_json({
                "reading": {
                    "temperature_c": reading.temperature_c,
                    "humidity_pct": reading.humidity_pct,
                    "pm25_ug_m3": reading.pm25_ug_m3,
                    "oxygen_pct": reading.oxygen_pct,
                    "salinity_ppt": reading.salinity_ppt,
                    "water_level_cm": reading.water_level_cm,
                },
                "snapshot": evaluate_twin(reading).to_dict(),
            })
            await asyncio.sleep(2)
    except WebSocketDisconnect:
        return
