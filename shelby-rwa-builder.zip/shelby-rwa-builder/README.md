# Shelby Real-time Digital Twin City & RWA Oracle

A runnable MVP that converts environmental sensor data into real-time **livability**, **structural health**, **maintenance cost**, and **RWA risk** signals.

## Features

- FastAPI REST API and OpenAPI docs
- WebSocket live digital-twin stream
- Environmental scoring engine
- Reactive risk alerts
- Responsive dashboard
- Aptos Move RWA registry with oracle authorization
- Docker and GitHub Actions CI
- Unit tests

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `http://localhost:8000` and API docs at `http://localhost:8000/docs`.

## Docker

```bash
docker compose up --build
```

## Evaluate a real reading

```bash
curl -X POST http://localhost:8000/api/v1/evaluate \
  -H "Content-Type: application/json" \
  -d '{
    "temperature_c": 31,
    "humidity_pct": 82,
    "pm25_ug_m3": 42,
    "oxygen_pct": 20.1,
    "salinity_ppt": 18,
    "water_level_cm": 12
  }'
```

## Architecture

```text
Sensors / Weather APIs
        ↓
FastAPI Oracle → Score Engine → WebSocket Dashboard
        ↓
Authorized Oracle Signer → Aptos Move Asset Registry
```

## Move contract

The contract in `contracts/` stores one asset per owner, restricts score updates to the configured oracle address, emits update events, and exposes a read-only score view.

```bash
cd contracts
aptos move compile
aptos move test
```

## Production next steps

1. Replace demo readings with signed IoT/weather adapters.
2. Persist readings in PostgreSQL/TimescaleDB.
3. Add nonce and signature verification for oracle payloads.
4. Submit score updates through an Aptos transaction worker.
5. Add asset NFT/token metadata and role-based administration.
6. Add geospatial/3D digital-twin visualization.
